Bean & Leaf v1.01

Start the project by clicking the run button in Android Studio. 

The app automatically takes you to the login page, where you can login or create a new account.

Clicking the register button will prompt you to either create a Student or Merchant account.

Students are able to view the map and select a store, where they can view its menu and add items to their bag.

Merchants have all of the capabilities of students but can also create/manage their own store(s).

The following features will be implemented in Bean & Leaf v1.02:

Since both merchants and students can "order" from coffee/tea shops on the map, every account should be able to
view their order history. This functionality is still in development.

The menu is currently hard-coded, so every store has the same basic menu. We are still developing
the ability to add new items or create customizable menus yet.

The directions to a selected store are still in development.
