package com.appfactory.kaldi;

public class Map
{

}