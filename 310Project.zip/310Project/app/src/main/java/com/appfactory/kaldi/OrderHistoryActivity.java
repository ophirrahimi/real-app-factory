package com.appfactory.kaldi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

public class OrderHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order__history);
        //LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout);
        //LOOP THROUGH STORED TRIPS FOR THE USER AND CREATE NEW BUTTONS FOR EACH ONE
//        Button newTrip = new Button(this);
//        newTrip.setText(trip.name);
    }
}
